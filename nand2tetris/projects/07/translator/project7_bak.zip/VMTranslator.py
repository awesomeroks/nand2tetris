root = "E:\\Google Drive\\Acads\\online courses\\nand2tetris\\nand2tetris\\projects\\07\\"
subfolder  = "MemoryAccess\\StaticTest\\"
programName = "StaticTest.vm"
vmFilename = root + subfolder + programName
vmFile = open(vmFilename,'r')
asmFile = open(root + subfolder + programName.split('.')[0] + '.asm','w')
label = 0

def writeInstruction(instructionToWrite):
    asmFile.write(instructionToWrite + '\n')

def loadValue():
    writeInstruction('@SP')
    writeInstruction('AM = M - 1') #indirect access
    writeInstruction('D = M')


def comparisonInstruction(change):
    # change = - 1 check less than
    # change = 0 check equal
    # change = 1 check greater than
    global label
    loadValue()
    writeInstruction('@SP')
    writeInstruction('A = M - 1')
    writeInstruction('D = M - D')
    writeInstruction('M = -1') #Assume that its lt
    writeInstruction('@label' + str(label))
    jumpString = 'J'
    if(change == -1):
        jumpString += 'LT'
    elif (change == 0):
        jumpString += 'EQ'
    elif(change == 1):
        jumpString += 'GT'
    writeInstruction('D;' + jumpString)
    writeInstruction('@SP')
    writeInstruction('A = M - 1')
    writeInstruction('M = 0')
    writeInstruction('(label' + str(label) + ')')
    label += 1

def executeArithmeticInstruction(instructionToExecute):
    if(instructionToExecute == 'add'):
        loadValue()
        writeInstruction('@SP')
        writeInstruction('AM = M - 1')
        writeInstruction('M = D + M')
        writeInstruction('@SP')
        writeInstruction('M = M + 1')
    elif(instructionToExecute == 'sub'):
        loadValue()
        writeInstruction('@SP')
        writeInstruction('AM = M - 1')
        writeInstruction('M = M - D')
        writeInstruction('@SP')
        writeInstruction('M = M + 1')
    elif(instructionToExecute == 'neg'):
        writeInstruction('@SP')
        writeInstruction('A = M - 1')
        writeInstruction('M = -M')
    elif(instructionToExecute == 'not'):
        writeInstruction('@SP')
        writeInstruction('A = M - 1')
        writeInstruction('M = !M')
    elif(instructionToExecute == 'or'):
        loadValue()
        writeInstruction('@SP')
        writeInstruction('A = M - 1')
        writeInstruction('M = D|M')
    elif(instructionToExecute == 'and'):
        loadValue()
        writeInstruction('@SP')
        writeInstruction('A = M - 1')
        writeInstruction('M = D&M')
    elif(instructionToExecute == 'eq'):
        comparisonInstruction(0)
    elif(instructionToExecute == 'gt'):
        comparisonInstruction(1)
    elif(instructionToExecute == 'lt'):
        comparisonInstruction(-1)

def putOnStackAndIncrement():
    writeInstruction('@SP')
    writeInstruction('A = M')
    writeInstruction('M = D')
    writeInstruction('@SP')
    writeInstruction('M = M + 1')

def memAccessPush(segmentString, index):
    writeInstruction('@' + str(index))
    writeInstruction('D = A')
    writeInstruction(segmentString)
    if(segmentString == '@3'):
        writeInstruction('A = A + D')
    else:
        writeInstruction('A = M + D')
    writeInstruction('D = M')



def memAccessPop(segmentString, index):
    writeInstruction('@' + str(index))
    writeInstruction('D = A')
    writeInstruction(segmentString)
    if(segmentString == '@3'):
        writeInstruction('D = A + D')
    else:
        writeInstruction('D = M + D')
    writeInstruction('@R13')
    writeInstruction('M = D')
    writeInstruction('@SP')
    writeInstruction('AM = M - 1')
    writeInstruction('D = M')
    writeInstruction('@R13')
    writeInstruction('A = M')
    writeInstruction('M = D')
def executeMemoryInstruction(pushPop, segment, index):
    global programName
    if(pushPop == "push"):
        if(segment == 'constant'):
            writeInstruction('@' + index)
            writeInstruction('D = A')
            putOnStackAndIncrement()
        elif (segment == 'static'):
            writeInstruction('@' + programName + '.' + str(index))
            writeInstruction('D = M')
            putOnStackAndIncrement()
        elif (segment == 'argument'):
            memAccessPush('@ARG', index)
            putOnStackAndIncrement()
        elif (segment == 'local'):
            memAccessPush('@LCL', index)
            putOnStackAndIncrement()
        elif (segment == 'this'):
            memAccessPush('@THIS', index)
            putOnStackAndIncrement()
        elif (segment == 'that'):
            memAccessPush('@THAT', index)
            putOnStackAndIncrement()
        elif (segment == 'temp'):
            writeInstruction('@' + str(int(index) + 5))
            writeInstruction('D = M')
            putOnStackAndIncrement()
        elif (segment == 'pointer'):
            memAccessPush('@3', index)
            putOnStackAndIncrement()
        else:
            writeInstruction('//Skipping')
    else:
        if(segment == 'static'):
            writeInstruction('@SP')
            writeInstruction('AM = M - 1')
            writeInstruction('D = M')
            writeInstruction('@' + programName + '.' + str(index))
            writeInstruction('M = D')
        elif (segment == 'this'):
            memAccessPop('@THIS', index)
        elif(segment == 'that'):
            memAccessPop('@THAT', index)
        elif(segment == 'argument'):
            memAccessPop('@ARG', index)
        elif(segment == 'local'):
            memAccessPop('@LCL', index)
        elif(segment == 'pointer'):
            memAccessPop('@3', index)

        elif(segment == 'temp'):
            memAccessPop('//', str(int(index) + 5) )
        else:
            writeInstruction('//Skipping')



def executeInstruction(instruction):
    instructionCommands = instruction.split(' ')
    if(instructionCommands[0] == 'push' or instructionCommands[0] == 'pop'):
        executeMemoryInstruction(instructionCommands[0],instructionCommands[1], instructionCommands[2])
    else:
        executeArithmeticInstruction(instruction)


for instruction in vmFile:
    instruction = instruction.strip()
    if(len(instruction)<1):
        continue
    if(instruction[0] == '/' and instruction[1] == '/'):
        continue
    print("Executing " + instruction)
    writeInstruction('//' + instruction)
    executeInstruction(instruction)


asmFile.close()
vmFile.close()



