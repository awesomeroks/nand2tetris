To run the program open up the VM emulator and point it to where the VM files are located.
You should have no animation on in the VM emulator.
Set the length of the snake as prompted and use the arrow keys to move the snake.
